
let typed;

typed = new Typed('#element', {
  strings: ['HealthyBites', 'WealthyEats', 'TastyDelights', 'FestiveFlavors', 'NourishNation', 'WholesomeFeast', 'SavorWellness', 'VibrantCuisine', 'NutriGourmet', 'DeliciousAbundance', 'GuiltFreeGoodies', 'FlavorfulWealth', 'FitFiesta', 'SustainableSavors', 'BalancedIndulgence'],
  typeSpeed: 50,
});